# Shell-Uploader
This is just a shell uploader which helps in uploading shell from your local machine. 

#Steps to Perform the activity
1. Upload this uploader if you are not able to upload the shell directly. (Due to AV detection or what so ever reason)
2. Browse for the path where you have uploaded the shell.
3. Upload your desired shell on the path (mentioned in uploader.php) in the format you require to upload.
4. Access the shell
5. Boom..!

